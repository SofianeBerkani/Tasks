﻿using System.Security.Cryptography.X509Certificates;
using static System.Net.Mime.MediaTypeNames;

namespace ProjectTaak
{
    internal class Program
    {
        public static bool isAdmin = false;
        public static Random rand = new Random();

        public static string[] itemNames = { "Dumbbell", "Yogamat", "Weerstandsbanden", "Kettlebell", "Sporthandschoenen" };
        public static int[] stock = { 100, 100, 100, 100, 100 };
        public static double[] prices = { 29, 39, 24, 14, 149 };
        public static string[] descriptions =
        {
        "Verstelbare halterset geschikt voor krachttraining thuis.",
        "Antislip yogamat met professionele grip en demping.",
        "Set van 5 elastische weerstandsbanden voor full-body workouts.",
        "12kg gietijzeren kettlebell voor functionele training.",
        "Comfortabele handschoenen voor betere grip en minder blaren."
        };
        public static string[] fabricationCountry = { "Belgium", "France", "Germany", "Usa", "UK" };


        public static string[] reviews =
   {
        "Beste gymstore ooit, alles topkwaliteit! – Jonas",
        "Mijn homegym is dankzij deze shop compleet! – Lisa",
        "Goede prijzen en snelle levering. – Mike",
        "De sporthandschoenen voelt super stevig aan! – Bram",
        "Yogamat is geweldig, beste grip die ik ooit had. – Emma",
        "Kettlebell training is nu mijn favoriete workout! – Noor",
        "Weerstandsbanden van topkwaliteit. – Sven",
        "Handschoenen passen perfect. – Lara",
        "Altijd tevreden met PowerGym kwaliteit! – Tim",
        "Mijn trainer raadde deze winkel aan terecht! – Sarah"
    };







        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Wat is je naam?");
            string userName = Console.ReadLine();
            Console.Clear();

            while (true)
            {

                Console.ForegroundColor = ConsoleColor.Blue;
                string storeName = "PowerGym Store";
                Console.WriteLine($"Welkom {userName} in {storeName}! De shop voor al jouw gym grief.");
                Console.ResetColor();
                Console.WriteLine();

                {
                    MyFirstStore.Logo();
                }

                Console.WriteLine();
                Console.WriteLine("Review van een klant:");
                MyFirstStore.ShowRandomReview();

                Console.WriteLine();
                Console.WriteLine("Druk op 1 de winkel binnen te komen!");
                Console.WriteLine($"1. {storeName}");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        MyFirstStore.Submenu();
                        break;
                    default:
                        Console.WriteLine("Dit is een ongeldige keuze");
                        break;
                }
                Console.WriteLine();
            }


        }
    }
}
