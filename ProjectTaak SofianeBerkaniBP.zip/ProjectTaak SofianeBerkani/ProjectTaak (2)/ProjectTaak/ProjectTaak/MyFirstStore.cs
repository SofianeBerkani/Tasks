﻿

using System;

namespace ProjectTaak
{
    internal class MyFirstStore
    {
        internal static void Submenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("MENU");
                Console.WriteLine("1. Item kopen");
                Console.WriteLine("2. Items bekijken");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("3. AdminLogin");
                Console.ResetColor();

                if (Program.isAdmin)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("4. Stock bijvullen (ADMIN)");
                    Console.ResetColor();
                }

                Console.WriteLine("5. Stoppen");
                Console.WriteLine("6. Menu");
                Console.Write("Maak een keuze: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        ShowAllItems();
                        Console.Write("Kies een item (nummer, 1 tot en met " + Program.itemNames.Length + "): ");
                        int buyIndex = Convert.ToInt32(Console.ReadLine()) - 1;

                        Console.Write("Hoeveel wil je kopen? ");
                        int amount = Convert.ToInt32(Console.ReadLine());

                        BuyItem(buyIndex, amount);
                        Console.ReadLine();
                        break;

                    case 2:
                        ShowAllItems();
                        Console.Write("Welk item wil je volledig bekijken? (nummer, 1 tot en met " + Program.itemNames.Length + "): ");
                        int viewIndex = Convert.ToInt32(Console.ReadLine()) - 1;

                        ShowItem(viewIndex);
                        ShowRandomReview();
                        Console.ReadLine();
                        break;

                    case 3:
                        Console.Write("Admin naam: ");
                        string userName = Console.ReadLine();
                        Console.Write("Admin password: ");
                        string pw = Console.ReadLine();
                        AdminLogin(pw, userName);
                        Console.ReadLine();
                        break;

                    case 4:
                        if (Program.isAdmin)
                        {
                            RefillStock();
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Geen toegang!");
                            Console.ReadLine();
                        }
                        break;

                    case 5:
                        Stoppen();
                        return;

                    case 6:
                        ShowMenu();
                        return;

                    default:
                        Console.WriteLine("Ongeldige keuze.");
                        Console.ReadLine();
                        break;
                }
            }
        }

        public static void BuyItem(int index, int amount)
        {
            Console.Clear();

            if (index < 0 || index >= Program.itemNames.Length)
            {
                Console.WriteLine("Ongeldige item index!");
                Console.ReadLine();
                return;
            }

            if (amount > Program.stock[index])
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Niet genoeg stock!");
                Console.ResetColor();
            }
            else
            {
                Program.stock[index] -= amount;
                double total = Program.prices[index] * amount;
                double withBTW = total * 1.21;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Succes! Je kocht {amount}x {Program.itemNames[index]}");
                Console.ResetColor();

                Console.WriteLine($"Totaal: {total:0.00} euro");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Met BTW (21%): {withBTW:0.00} euro");
                Console.ResetColor();
            }
        }

        public static void ShowAllItems()
        {
            Console.Clear();
            Console.WriteLine("Alle fitness items");

            for (int i = 0; i < Program.itemNames.Length; i++)
            {
                if (Program.stock[i] == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{i + 1}. {Program.itemNames[i]} - uitverkocht");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine($"{i + 1}. {Program.itemNames[i]} - Stock: {Program.stock[i]} - {Program.prices[i]:F2} euro");
                }
            }

            Console.WriteLine();
            Console.WriteLine("Review van onze klanten:");
            ShowRandomReview();
        }

        public static void ShowItem(int index)
        {
            Console.Clear();

            Console.WriteLine($" ITEM {index + 1} ");
            Console.WriteLine($"Naam: {Program.itemNames[index]}");
            if (Program.stock[index] == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Stock: uitverkocht");
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine($"Stock: {Program.stock[index]}");
            }
            Console.WriteLine($"Prijs: {Program.prices[index]:F2} euro");
            Console.WriteLine($"Beschrijving: {Program.descriptions[index]}");
            Console.WriteLine($"Herkomst: {Program.fabricationCountry[index]}");
            Console.WriteLine();
            Console.WriteLine("Druk op ENTER om terug te gaan naar het MENU");
        }

        public static void AdminLogin(string adminPassword, string userName)
        {

            
            if (adminPassword == "AP")
            {
              
                Program.isAdmin = true;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Welkom {userName}, je bent nu ingelogd als admin!");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Foute inloggegevens!");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Druk op ENTER om terug te gaan naar het MENU");
            }
            
        }

        public static void Stoppen()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Tot de volgende workout! Programma wordt afgesloten.");
            Console.ResetColor();
        }

        public static void RefillStock()
        {
            Console.Clear();
            Console.WriteLine("Stock bijvullen");
            for (int i = 0; i < Program.itemNames.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Program.itemNames[i]} (huidige stock: {Program.stock[i]})");
            }

            Console.Write("Kies item (nummer): ");
            int index = Convert.ToInt32(Console.ReadLine()) - 1;

            Console.Write("Hoeveel wil je toevoegen? ");
            int amount = Convert.ToInt32(Console.ReadLine());

            Program.stock[index] += amount;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Stock bijgewerkt! Er zijn nu {Program.stock[index]} stuks van {Program.itemNames[index]}.");
            Console.ResetColor();
        }

        public static void ShowRandomReview()
        {
            int r = Program.rand.Next(Program.reviews.Length);
            Console.WriteLine($"{Program.reviews[r]}");
        }


        public static void Logo()
        {
            string[,] logo =
        {
            { "S","S","S","S","S","S","S" },
            { "S"," "," "," "," "," "," " },
            { "S"," "," "," "," "," "," " },
            { "S","S","S","S","S","S","S" },
            { " "," "," "," "," "," ","S" },
            { " "," "," "," "," "," ","S" },
            { "S","S","S","S","S","S","S" }
        };

            

            for (int r = 0; r < logo.GetLength(0); r++)
            {
                for (int c = 0; c < logo.GetLength(1); c++)
                {
                    Console.Write(logo[r, c]);
                }
                Console.WriteLine();
            }

        }
        public static void ShowMenu()
        {
            Console.Clear();            
        }
       

    }
}
