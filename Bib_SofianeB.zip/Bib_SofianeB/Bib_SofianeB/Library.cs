﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_SofianeB
{
    public class Library
    {
        public string Name;
        private List<Book> Books;

        public Library(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                name = "Default Library";
            }

            Name = name;
            Books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            Books.Add(book);
        }

        public void RemoveBook(string title, string author)
        {
            Book found = null;
            foreach (Book b in Books)
            {
                if (b.Title.ToLower() == title.ToLower() && b.Author.ToLower() == author.ToLower())
                {
                    found = b;
                    break;
                }
            }

            if (found != null)
            {
                Books.Remove(found);
                Console.WriteLine("Book removed successfully!");
            }
            else
            {
                Console.WriteLine("Book not found!");
            }
        }

        public Book FindByTitleAuthor(string title, string author)
        {
            foreach (Book b in Books)
            {
                if (b.Title.ToLower() == title.ToLower() && b.Author.ToLower() == author.ToLower())
                {
                    return b;
                }
            }
            return null;
        }

        public Book FindByISBN(string isbn)
        {
            foreach (Book b in Books)
            {
                if (b.ISBN == isbn)
                {
                    return b;
                }
            }
            return null;
        }

        public void FindByAuthor(string author)
        {
            bool found = false;
            foreach (Book b in Books)
            {
                if (b.Author.ToLower() == author.ToLower())
                {
                    b.ShowInfo();
                    found = true;
                }
            }
            if (!found)
                Console.WriteLine("No books found for this author.");
        }

        public void FindByGenre(Genre genre)
        {
            bool found = false;
            foreach (Book b in Books)
            {
                if (b.BookGenre == genre)
                {
                    b.ShowInfo();
                    found = true;
                }
            }
            if (!found)
                Console.WriteLine("No books found for this genre.");
        }

        public void ShowAllBooks()
        {
            if (Books.Count == 0)
            {
                Console.WriteLine("No books available in the library.");
                return;
            }

            foreach (Book b in Books)
            {
                b.ShowInfo();
            }
        }

        public void LoadFromCSV(string path)
        {
            if (!File.Exists(path))
            {
                Console.WriteLine("File not found!");
                return;
            }

            string[] lines = File.ReadAllLines(path);
            foreach (string line in lines)
            {
                string[] data = line.Split(',');
                if (data.Length < 8)
                    continue;

                string title = data[0];
                string author = data[1];
                string isbn = data[2];
                Genre genre = Genre.Other;
                try { genre = (Genre)Enum.Parse(typeof(Genre), data[3]); } catch { }

                string publisher = data[4];
                int year = Convert.ToInt32(data[5]);
                int pages = Convert.ToInt32(data[6]);
                double price = Convert.ToDouble(data[7]);

                Book b = new Book(title, author, this);
                b.SetISBN(isbn);
                b.SetGenre(genre);
                b.SetPublisher(publisher);
                b.SetYear(year);
                b.SetPages(pages);
                b.SetPrice(price);
            }

            Console.WriteLine("Books loaded successfully from CSV!");
        }
    }
}