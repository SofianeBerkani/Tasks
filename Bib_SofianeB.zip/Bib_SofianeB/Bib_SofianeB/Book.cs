﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_SofianeB
{
    public enum Genre
    {
        Fiction,
        NonFiction,
        Science,
        History,
        Mystery,
        Romance,
        Biography,
        Fantasy,
        Other
    }

    public class Book
    {
        public string Title;
        public string Author;
        public string ISBN;
        public Genre BookGenre;
        public string Publisher;
        public int YearPublished;
        public int Pages;
        public double Price;
        public bool Available;

        private Library _library;

        public Book(string title, string author, Library library)
        {
            if (string.IsNullOrEmpty(title))
            {
                Console.WriteLine("Title cannot be empty.");
            }

            if (string.IsNullOrEmpty(author))
            {
                Console.WriteLine("Author cannot be empty.");
            }

            if (library == null)
            {
                Console.WriteLine("Library cannot be null.");
            }

            Title = title;
            Author = author;
            Available = true;
            _library = library;

            // Automatically add to library
            _library.AddBook(this);
        }

        public void SetISBN(string isbn)
        {
            if (isbn.Length != 13)
            {
                Console.WriteLine("ISBN must have 13 digits.");
            }
            else
            {
                ISBN = isbn;
            }
        }

        public void SetGenre(Genre genre)
        {
            BookGenre = genre;
        }

        public void SetPublisher(string publisher)
        {
            Publisher = publisher;
        }

        public void SetYear(int year)
        {
            if (year > 1400 && year <= DateTime.Now.Year)
                YearPublished = year;
        }

        public void SetPages(int pages)
        {
            if (pages > 0)
                Pages = pages;
        }

        public void SetPrice(double price)
        {
            if (price >= 0)
                Price = price;
        }

        public void ShowInfo()
        {
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("Title       : " + Title);
            Console.WriteLine("Author      : " + Author);
            Console.WriteLine("ISBN        : " + ISBN);
            Console.WriteLine("Genre       : " + BookGenre);
            Console.WriteLine("Publisher   : " + Publisher);
            Console.WriteLine("Year        : " + YearPublished);
            Console.WriteLine("Pages       : " + Pages);
            Console.WriteLine("Price (€)   : " + Price);
            Console.WriteLine("Available   : " + (Available ? "Yes" : "No"));
            Console.WriteLine("---------------------------------------------------\n");
        }
    }
}