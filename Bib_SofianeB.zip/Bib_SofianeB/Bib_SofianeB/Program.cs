﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_SofianeB
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Library name: ");
            string name = Console.ReadLine();
            Library lib = new Library(name);

            bool running = true;
            while (running)
            {
                Console.WriteLine("\n=== Library Menu ===");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Add Info to Book");
                Console.WriteLine("3. Show Book Info");
                Console.WriteLine("4. Search Book");
                Console.WriteLine("5. Remove Book");
                Console.WriteLine("6. Show All Books");
                Console.WriteLine("7. Load from CSV");
                Console.WriteLine("0. Exit");
                Console.Write("Choose option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter Title: ");
                        string t = Console.ReadLine();
                        Console.Write("Enter Author: ");
                        string a = Console.ReadLine();
                        new Book(t, a, lib);
                        Console.WriteLine("Book added successfully!");
                        break;

                    case "2":
                        Console.Write("Enter Title: ");
                        t = Console.ReadLine();
                        Console.Write("Enter Author: ");
                        a = Console.ReadLine();
                        Book bk = lib.FindByTitleAuthor(t, a);
                        if (bk == null)
                        {
                            Console.WriteLine("Book not found!");
                            break;
                        }

                        Console.WriteLine("1. ISBN  2. Genre  3. Publisher  4. Year  5. Pages  6. Price");
                        Console.Write("Select: ");
                        string opt = Console.ReadLine();

                        if (opt == "1")
                        {
                            Console.Write("Enter ISBN: ");
                            bk.SetISBN(Console.ReadLine());
                        }
                        else if (opt == "2")
                        {
                            Console.WriteLine("Genres: Fiction, NonFiction, Science, History, Mystery, Romance, Biography, Fantasy, Other");
                            Console.Write("Enter Genre: ");
                            string g = Console.ReadLine();
                            try
                            {
                                Genre genre = (Genre)Enum.Parse(typeof(Genre), g);
                                bk.SetGenre(genre);
                            }
                            catch { Console.WriteLine("Invalid genre!"); }
                        }
                        else if (opt == "3")
                        {
                            Console.Write("Enter Publisher: ");
                            bk.SetPublisher(Console.ReadLine());
                        }
                        else if (opt == "4")
                        {
                            Console.Write("Enter Year: ");
                            bk.SetYear(Convert.ToInt32(Console.ReadLine()));
                        }
                        else if (opt == "5")
                        {
                            Console.Write("Enter Pages: ");
                            bk.SetPages(Convert.ToInt32(Console.ReadLine()));
                        }
                        else if (opt == "6")
                        {
                            Console.Write("Enter Price: ");
                            bk.SetPrice(Convert.ToDouble(Console.ReadLine()));
                        }

                        Console.WriteLine("Information updated!");
                        break;

                    case "3":
                        Console.Write("Enter Title: ");
                        t = Console.ReadLine();
                        Console.Write("Enter Author: ");
                        a = Console.ReadLine();
                        bk = lib.FindByTitleAuthor(t, a);
                        if (bk != null)
                            bk.ShowInfo();
                        else
                            Console.WriteLine("Book not found!");
                        break;

                    case "4":
                        Console.WriteLine("1. By Title + Author");
                        Console.WriteLine("2. By ISBN");
                        Console.WriteLine("3. By Author");
                        Console.WriteLine("4. By Genre");
                        Console.Write("Select: ");
                        string s = Console.ReadLine();

                        if (s == "1")
                        {
                            Console.Write("Title: ");
                            t = Console.ReadLine();
                            Console.Write("Author: ");
                            a = Console.ReadLine();
                            bk = lib.FindByTitleAuthor(t, a);
                            if (bk != null) bk.ShowInfo(); else Console.WriteLine("Not found!");
                        }
                        else if (s == "2")
                        {
                            Console.Write("ISBN: ");
                            bk = lib.FindByISBN(Console.ReadLine());
                            if (bk != null) bk.ShowInfo(); else Console.WriteLine("Not found!");
                        }
                        else if (s == "3")
                        {
                            Console.Write("Author: ");
                            lib.FindByAuthor(Console.ReadLine());
                        }
                        else if (s == "4")
                        {
                            Console.Write("Genre: ");
                            try
                            {
                                Genre g = (Genre)Enum.Parse(typeof(Genre), Console.ReadLine());
                                lib.FindByGenre(g);
                            }
                            catch { Console.WriteLine("Invalid genre!"); }
                        }
                        break;

                    case "5":
                        Console.Write("Enter Title: ");
                        t = Console.ReadLine();
                        Console.Write("Enter Author: ");
                        a = Console.ReadLine();
                        lib.RemoveBook(t, a);
                        break;

                    case "6":
                        lib.ShowAllBooks();
                        break;

                    case "7":
                        Console.Write("Enter CSV file path: ");
                        lib.LoadFromCSV(Console.ReadLine());
                        break;

                    case "0":
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Invalid option!");
                        break;
                }
            }
        }
    }
}