document.addEventListener("DOMContentLoaded", () => {
  const addToCartButtons = document.querySelectorAll(".add-to-cart");

  addToCartButtons.forEach((button) => {
    button.addEventListener("click", addToCart);
  });

  function addToCart(event) {
    event.preventDefault();
    const hairItem = event.target.closest(".hair-item");
    const hairDescription =
      hairItem.querySelector(".hair-description").textContent;
    const hairPrice = parseFloat(
      hairItem.querySelector(".add-to-cart p").textContent.replace("€", "")
    );
    const hairImage = hairItem.querySelector("img").src;
    let cartItem = null;
    const existingCartItem = document.querySelector(
      `#cart-items li[data-description="${hairDescription}"]`
    );

    if (existingCartItem) {
      const quantity =
        parseInt(existingCartItem.getAttribute("data-quantity")) + 1;
      const totalPrice = quantity * hairPrice;
      existingCartItem.setAttribute("data-quantity", quantity);
      existingCartItem.querySelector(
        ".quantity"
      ).textContent = `(${quantity}x)`;
      existingCartItem.querySelector(
        ".price"
      ).textContent = `€${totalPrice.toFixed(2)}`;
    } else {
      cartItem = document.createElement("li");
      cartItem.setAttribute("data-description", hairDescription);
      cartItem.setAttribute("data-quantity", 1);
      cartItem.innerHTML = `
              <img src="${hairImage}" alt="${hairDescription}" width="50">
              <span>${hairDescription} <span class="quantity">(1x)</span></span>
              <span class="price">€${hairPrice.toFixed(2)}</span>
              <button class="remove-from-cart">X</button>
          `;
      document.getElementById("cart-items").appendChild(cartItem);
    }

    document.getElementById("cart-empty").style.display = "none";

    const removeFromCartButtons =
      document.querySelectorAll(".remove-from-cart");
    removeFromCartButtons.forEach((button) => {
      button.addEventListener("click", removeFromCart);
    });
  }

  function removeFromCart(event) {
    const cartItem = event.target.closest("li");
    cartItem.remove();

    if (!document.getElementById("cart-items").hasChildNodes()) {
      document.getElementById("cart-empty").style.display = "block";
    }
  }
});
