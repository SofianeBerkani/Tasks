document.addEventListener("DOMContentLoaded", () => {
  const wishlistButtons = document.querySelectorAll(".wishlist");

  wishlistButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const img = button.querySelector("img");
      if (img.src.includes("heart-icon-red.webp")) {
        img.src = "./assets/heart-icon-white.webp";
      } else {
        img.src = "./assets/heart-icon-red.webp";
      }
    });
  });
});

let wishlist = [];

const wishlistButtons = document.querySelectorAll(".wishlist");

wishlistButtons.forEach((button) => {
  button.addEventListener("click", toggleWishlistItem);
});

function toggleWishlistItem(event) {
  const button = event.target;
  const hairItem = button.parentNode.parentNode;
  const hairId = hairItem.querySelector(".product-link").href.split("/").pop();
  const hairTitle = hairItem.querySelector(".hair-description").textContent;

  if (button.classList.contains("heart-icon-red")) {
    button.classList.remove("heart-icon-red");
    button.classList.add("heart-icon-white");
    removeWishlistItem(hairId);
  } else {
    button.classList.remove("heart-icon-white");
    button.classList.add("heart-icon-red");
    addWishlistItem(hairId, hairTitle);
  }
}

function addWishlistItem(hairId, hairTitle) {
  wishlist.push({ id: hairId, title: hairTitle });
  updateWishlistUI();
}

function removeWishlistItem(hairId) {
  const index = wishlist.findIndex((item) => item.id === hairId);
  if (index !== -1) {
    wishlist.splice(index, 1);
  }
  updateWishlistUI();
}

function updateWishlistUI() {
  const wishlistContent = document.querySelector(".wishlist-content");
  wishlistContent.innerHTML = "";
  if (wishlist.length === 0) {
    wishlistContent.innerHTML = '<p id="wishlist">Je Wishlist is leeg</p>';
  } else {
    wishlist.forEach((item) => {
      const wishlistItem = document.createElement("p");
      wishlistItem.textContent = item.title;
      wishlistContent.appendChild(wishlistItem);
    });
  }
}
